//add a property to object
let object = {}
object.ramesh ='yes';
object['suresh'] = 'no';
console.log(object)