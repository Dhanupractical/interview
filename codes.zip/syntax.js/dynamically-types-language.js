let value = 'dhanu';
value = 10;

console.log(value)