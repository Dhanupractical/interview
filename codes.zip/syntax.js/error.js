mamaError = new Error('message',  { cause: 'err' });
console.log(mamaError);