(function ramu(){
    console.log("a")
})();

const ramesh = (function (){
    console.log("b")
})();


(()=>{
    console.log('5')
})();