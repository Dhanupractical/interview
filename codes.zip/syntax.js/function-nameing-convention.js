function _123consoleYes (){
    console.log('yes')
}

_123consoleYes();

const callYEs = function (){
    console.log('yes')
}

callYEs();