// function multiply(firstSrgument, ...rest){
//   console.log(firstSrgument);
//   console.log(...rest)
// }

// multiply(3, 5, 6)