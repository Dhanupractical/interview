const caseValue = 1;
let day = 'sunday'

switch (caseValue){

    case 0 :
     day = "monday";
    break;

    case 1 :
     day = "tuesday";

    case 3 :
     day = "webnesday";
}

console.log(day)