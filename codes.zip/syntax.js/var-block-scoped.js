// let toPrint = 'Hello World.';
// {
//     let toPrint = 'Goodbye World.';
// }
// console.log(toPrint);

// var toVar = 'entra mama';
// {
//     var toVar = 'this is block';
// }
// console.log(toVar)