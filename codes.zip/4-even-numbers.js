const evenNumbers = [];
for (let i=1; i<=10; i++){
   if(i%2 === 0){
    evenNumbers.push(i)
   }
}
console.log(evenNumbers);