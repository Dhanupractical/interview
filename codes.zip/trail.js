const caseValue = 1;
let day = 'sunday';

switch(caseValue){
  case 0:
    day = 'monday';
    break;

  case 1:
    day = 'tuesday';
    break;

  case 2:
    day = 'wednesday';
    break;
}

console.log(day)