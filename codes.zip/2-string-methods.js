
// 1)
// const string = 'dhanu danish rahul dhanu sreejuSir danish'
// const matchedString = string.match(/danish/g);
// console.log(matchedString);


// 2)
// let text = "HELLO WORLD";
// text.charAt(10)
// text.charCodeAt(10)


// 3)
// let text1 = "sea";
// let text2 = "food";
// let text3 = "Have a nice day!";
// text1.concat(" ",text2," ",text3)


// 4)
// let text = "Hello world";
// console.log(text.endsWith('world'))
// console.log(text.startsWith('hello'))


// 5)
// console.log(String.fromCharCode(72, 69, 76, 76, 79))



// 6)
// let text = "Hello world, welcome to the universe.";
// console.log(text.includes('world', 5) );
// console.log(text.indexOf('welcome'))


// 7)
// let text = "The rain in SPAIN stays mainly in the plain";
// console.log(text.match('stays'))
// console.log(text.match(/stays/))



// 8)
// let text = "Mr Blue has a blue house and a Blue car";
// let replacedText = text.replace(/blue/gi, 'red');
// console.log(replacedText)



// 9)
// let text = "Hello World!";
// console.log(text.toLowerCase())
// console.log(text.toUpperCase())



// 10)
// let text = "       Hello  World!        ";
// console.log(text.trim())


